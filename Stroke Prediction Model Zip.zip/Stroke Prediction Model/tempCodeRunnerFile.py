svmmodel = pickle.load(open('svmmodel.sav','rb'))
dtcmodel = pickle.load(open('dtcmodel.sav','rb'))